SELECT *
FROM jogo
WHERE jogo.dev_id = conta.conta_id;
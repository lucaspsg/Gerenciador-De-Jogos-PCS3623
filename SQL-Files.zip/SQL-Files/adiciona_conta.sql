INSERT INTO conta
(conta_id, nome_conta, email, senha, carteira, desenvolvedor, imagem_perfil)
VALUES
(, , , , , , );
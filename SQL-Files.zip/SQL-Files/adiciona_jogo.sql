INSERT INTO jogo
(game_id, nome_jogo, preco, tamanho, dev_id, data_lanc, categoria, quant_downloads, descricao, capa)
VALUES
(, , , , , , , , , );
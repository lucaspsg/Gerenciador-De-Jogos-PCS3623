INSERT INTO conquista
(jogo_id, conquista_id, nome_conquista, descricao_conquista)
VALUES
(, , , );